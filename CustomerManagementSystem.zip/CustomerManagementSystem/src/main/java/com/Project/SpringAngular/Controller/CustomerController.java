package com.Project.SpringAngular.Controller;
import com.Project.SpringAngular.DTO.CustomerDTO;
import com.Project.SpringAngular.DTO.CustomerSaveDTO;
import com.Project.SpringAngular.DTO.CustomerUpdateDTO;
import com.Project.SpringAngular.Entity.Customer;
import com.Project.SpringAngular.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200")
//@RequestMapping("cms/c1/customer")
public class CustomerController
{
    @Autowired
    private CustomerService customerService;

    @PostMapping(path = "/customer")
    public String saveCustomer(@RequestBody CustomerSaveDTO customerSaveDTO)
    {
        String id = customerService.addCustomer(customerSaveDTO);
        return "Customer Created successfully.";
    }

    @GetMapping(path = "/customer")
    public List<CustomerDTO> getAllCustomer()
    {
       List<CustomerDTO>allCustomers = customerService.getAllCustomer();
       return allCustomers;
    }

    @GetMapping(path="/customer/{customerid}")
    public Customer getCustomerById(@PathVariable(value = "customerid") int customerid) {
    	return customerService.getCustomerById(customerid);
    }
    
    
    @PutMapping(path = "/customer/{customerid}")

    public String updateCustomer(@RequestBody CustomerUpdateDTO customerUpdateDTO,@PathVariable(value = "customerid") int customerid)
    {
        return customerService.updateCustomers(customerUpdateDTO, customerid);
    }

    @DeleteMapping(path = "/customer/{customerid}")
    public String deleteCustomer(@PathVariable(value = "customerid") int customerid)
    {
        boolean deletecustomer = customerService.deleteCustomer(customerid);
        return "deleted";
    }

}