import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { AboutComponent } from './about/about.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'customers', component: CustomerListComponent},
  {path:'addCustomers', component : CreateCustomerComponent},
  {path:'about', component : AboutComponent},
  {path:'', component : HomeComponent},
  {path:'update-customer/:customerid', component : UpdateCustomerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
