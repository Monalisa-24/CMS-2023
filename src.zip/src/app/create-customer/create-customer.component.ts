import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerServiceService } from '../customer-service.service';
import { ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';



@Component({
  selector: 'app-create-customer',
  templateUrl: './create-customer.component.html',
  styleUrls: ['./create-customer.component.scss']
})
export class CreateCustomerComponent implements OnInit {

  customer: Customer = new Customer();
  constructor(private CustomerService : CustomerServiceService, private cdr: ChangeDetectorRef, private router : Router) { }

  ngOnInit(): void {
  }

  addCustomersData() {
    this.CustomerService.save(this.customer).subscribe(
       (data) => {
        console.log('Customer Registration is successful', data);
        alert('Customer Registration is successful'); 
       }
      ,
      error => console.error('Registration failed!', error),
    );
}
}
