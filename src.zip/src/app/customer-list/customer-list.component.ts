import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';
import { Customer } from '../customer';
import { Router } from '@angular/router';


@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.scss']
})


export class CustomerListComponent implements OnInit {

  customers : Customer[] = [];
  constructor(private CustomerService : CustomerServiceService, private router:Router) { }

  

  ngOnInit(): void {
    this.CustomerService.getAllCustomer().subscribe(data=>{
      this.customers=data;
    })
  }

  updateCustomer(customerid:number){
    console.log(customerid);
    this.router.navigate(["update-customer",customerid]);
  }

  deleteCustomer(customerid:number){
    this.CustomerService.deleteCustomer(customerid).subscribe(data=>{
      alert("Deleted successfully.");
      this.router.navigate(["/customer",customerid]);
    })
  }

  
}
