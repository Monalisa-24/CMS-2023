import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './customer';
// import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {
  

  baseURL="http://localhost:8080/customer";
  
  constructor(private httpClient: HttpClient) { }

  save(customer: Customer) {
    console.log(customer);
    return this.httpClient.post(`${this.baseURL}`, customer,{responseType: 'text'});
  }
  

  getAllCustomer() : Observable<Customer[]>{
    return this.httpClient.get<Customer[]>(`${this.baseURL}`);
  }

  getCustomerById(customerid:number): Observable<Customer>{
    console.log(customerid);
    return this.httpClient.get<Customer>(`${this.baseURL}/${customerid}`);
  }

  updateCustomersData(customer: Customer, customerid:number): Observable<Customer> {
    return this.httpClient.put<Customer>(`${this.baseURL}/${customerid}`, customer);
  }

  deleteCustomer(customerid:number): Observable<Object>{
    return this.httpClient.delete<string>(`${this.baseURL}/${customerid}`);
  }

}
