export class Customer {
    customerid!:number;
    customername!:string;
    customeraddress!:string;
    mobile!:string;
}
