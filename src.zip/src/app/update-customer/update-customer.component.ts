import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.scss']
})
export class UpdateCustomerComponent implements OnInit {

  constructor(private activeRoute:ActivatedRoute, private customerService:CustomerServiceService, private router:Router) { }
  customerid!:number;
  customer: Customer = new Customer();

  ngOnInit(): void {
    this.customerid=this.activeRoute.snapshot.params['customerid'];
    console.log(this.customerid);
    this.customerService.getCustomerById(this.customerid).subscribe(data=>{
      this.customer = data;
      console.log(this.customer);
    })
  }

  updateCustomersData(){
    this.customerService.updateCustomersData(this.customer, this.customerid).subscribe(data=>{
      alert("Updated successfully.");
      this.router.navigate(['/customers']);
    }, error=>alert("Updation failed!"));
  }

}
